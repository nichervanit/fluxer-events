-- Feed tokens let a user get a private, unguessable ICS subscription URL
-- (e.g. https://fluxer.app/calendar/feed/<token>.ics) without exposing
-- their session/auth cookie to Apple/Google Calendar's servers.

CREATE TABLE IF NOT EXISTS calendar_feed_tokens (
  token TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  scope TEXT NOT NULL CHECK (scope IN ('personal', 'community')),
  community_id TEXT,              -- required when scope = 'community'
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  revoked_at TEXT,

  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_feed_tokens_user ON calendar_feed_tokens (user_id);
