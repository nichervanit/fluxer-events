import type { CommunityEvent, RecurrenceRule } from "../types";

/**
 * Generates a subscribable ICS (iCalendar, RFC 5545) feed for a set of
 * events. This is a one-way, read-only feed — the standard way Discord-
 * alternatives and most calendar features integrate with Apple Calendar /
 * Google Calendar / Outlook ("subscribe by URL").
 *
 * This is NOT full CalDAV (RFC 4791). True CalDAV is a WebDAV extension
 * supporting PROPFIND/REPORT/PUT for two-way sync against a calendar
 * collection, with per-calendar auth. That's a materially larger project.
 * If two-way sync is a hard requirement, flag that with maintainers before
 * building it — this feed does not provide it.
 */

const CRLF = "\r\n";
const PRODID = "-//Fluxer//Events//EN";

export function generateIcsFeed(
  calendarName: string,
  events: CommunityEvent[]
): string {
  const lines: string[] = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    `PRODID:${PRODID}`,
    "CALSCALE:GREGORIAN",
    `X-WR-CALNAME:${escapeText(calendarName)}`,
    "REFRESH-INTERVAL;VALUE=DURATION:PT30M",
    "X-PUBLISHED-TTL:PT30M",
  ];

  for (const event of events) {
    lines.push(...buildVEvent(event));
  }

  lines.push("END:VCALENDAR");

  // RFC 5545 requires CRLF line endings and 75-octet line folding.
  return lines.map(foldLine).join(CRLF) + CRLF;
}

function buildVEvent(event: CommunityEvent): string[] {
  const lines = [
    "BEGIN:VEVENT",
    `UID:${event.id}@fluxer.app`,
    `DTSTAMP:${toIcsUtc(new Date(event.updatedAt))}`,
    `DTSTART:${toIcsUtc(new Date(event.startTime))}`,
    `DTEND:${toIcsUtc(new Date(event.endTime))}`,
    `SUMMARY:${escapeText(event.title)}`,
  ];

  if (event.description) {
    lines.push(`DESCRIPTION:${escapeText(event.description)}`);
  }

  if (event.location.type === "external" && event.location.description) {
    lines.push(`LOCATION:${escapeText(event.location.description)}`);
  } else if (event.location.type === "voice_channel") {
    lines.push(`LOCATION:${escapeText("Fluxer voice channel")}`);
  }

  const rrule = toRRule(event.recurrence);
  if (rrule) lines.push(`RRULE:${rrule}`);

  lines.push(`LAST-MODIFIED:${toIcsUtc(new Date(event.updatedAt))}`);
  lines.push("END:VEVENT");
  return lines;
}

/** Converts our RecurrenceRule into an RFC 5545 RRULE value. */
export function toRRule(rule: RecurrenceRule): string | null {
  if (rule.frequency === "none") return null;

  const parts: string[] = [`FREQ=${rule.frequency.toUpperCase()}`];

  if (rule.interval && rule.interval > 1) {
    parts.push(`INTERVAL=${rule.interval}`);
  }

  if (rule.frequency === "weekly" && rule.byWeekday?.length) {
    const dayMap = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];
    parts.push(`BYDAY=${rule.byWeekday.map((d) => dayMap[d]).join(",")}`);
  }

  if (rule.count) {
    parts.push(`COUNT=${rule.count}`);
  } else if (rule.until) {
    parts.push(`UNTIL=${toIcsUtc(new Date(rule.until))}`);
  }

  return parts.join(";");
}

function toIcsUtc(date: Date): string {
  // YYYYMMDDTHHMMSSZ
  return date.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
}

function escapeText(text: string): string {
  return text
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\n/g, "\\n");
}

/** RFC 5545 §3.1: lines must be folded at 75 octets, continuation lines
 *  start with a single space. */
function foldLine(line: string): string {
  if (line.length <= 75) return line;
  const parts: string[] = [];
  let rest = line;
  parts.push(rest.slice(0, 75));
  rest = rest.slice(75);
  while (rest.length > 0) {
    parts.push(" " + rest.slice(0, 74));
    rest = rest.slice(74);
  }
  return parts.join(CRLF);
}
