import { Router, type Request, type Response } from "express";
import { randomBytes } from "crypto";
import type Database from "better-sqlite3";
import { EventsService } from "../events.service";
import { generateIcsFeed } from "./ics";

interface FeedTokenRow {
  token: string;
  user_id: string;
  scope: "personal" | "community";
  community_id: string | null;
  revoked_at: string | null;
}

export function createCalDavRouter(
  db: Database.Database,
  service: EventsService,
  requireAuth: (req: Request, res: Response, next: () => void) => void,
  requireCommunityMember: (
    req: Request,
    res: Response,
    next: () => void
  ) => void
): Router {
  const router = Router();

  // -- Issuing a feed URL (requires auth) ----------------------------------

  router.post(
    "/users/@me/calendar-feed",
    requireAuth,
    (req: Request, res: Response) => {
      const token = randomBytes(24).toString("base64url");
      db.prepare(
        `INSERT INTO calendar_feed_tokens (token, user_id, scope, community_id)
         VALUES (?, ?, 'personal', NULL)`
      ).run(token, req.userId);
      res.status(201).json({
        feedUrl: `/calendar/feed/${token}.ics`,
        // webcal:// scheme prompts most calendar apps to offer a
        // "subscribe" action directly instead of downloading a file.
        webcalUrl: `webcal://${req.get("host")}/calendar/feed/${token}.ics`,
      });
    }
  );

  router.post(
    "/communities/:communityId/calendar-feed",
    requireAuth,
    requireCommunityMember,
    (req: Request, res: Response) => {
      const token = randomBytes(24).toString("base64url");
      db.prepare(
        `INSERT INTO calendar_feed_tokens (token, user_id, scope, community_id)
         VALUES (?, ?, 'community', ?)`
      ).run(token, req.userId, req.params.communityId);
      res.status(201).json({
        feedUrl: `/calendar/feed/${token}.ics`,
        webcalUrl: `webcal://${req.get("host")}/calendar/feed/${token}.ics`,
      });
    }
  );

  router.delete(
    "/users/@me/calendar-feed/:token",
    requireAuth,
    (req: Request, res: Response) => {
      db.prepare(
        `UPDATE calendar_feed_tokens SET revoked_at = datetime('now')
         WHERE token = ? AND user_id = ?`
      ).run(req.params.token, req.userId);
      res.status(204).end();
    }
  );

  // -- Serving the feed (NOT behind requireAuth — Apple/Google Calendar's
  //    servers fetch this directly and can't do cookie-based auth) --------

  router.get("/calendar/feed/:token.ics", (req: Request, res: Response) => {
    const row = db
      .prepare(
        `SELECT * FROM calendar_feed_tokens WHERE token = ? AND revoked_at IS NULL`
      )
      .get(req.params.token) as FeedTokenRow | undefined;

    if (!row) {
      res.status(404).type("text/plain").send("Feed not found or revoked.");
      return;
    }

    const events =
      row.scope === "personal"
        ? service.listPersonalEvents(row.user_id)
        : service.listCommunityEvents(row.community_id!, row.user_id);

    const calendarName =
      row.scope === "personal" ? "My Fluxer events" : "Fluxer community events";

    const ics = generateIcsFeed(calendarName, events);
    res.type("text/calendar; charset=utf-8").send(ics);
  });

  return router;
}
