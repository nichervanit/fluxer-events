import { Router, type Request, type Response, type NextFunction } from "express";
import {
  EventsService,
  ValidationError,
  ForbiddenError,
  NotFoundError,
} from "./events.service";

/**
 * Mounts event routes onto an Express app.
 * Assumes upstream middleware has already populated `req.userId`
 * (adapt to however Fluxer's auth middleware names it) and that
 * community membership checks happen in a `requireCommunityMember`
 * middleware — plug in the real one here.
 */
export function createEventsRouter(
  service: EventsService,
  requireAuth: (req: Request, res: Response, next: NextFunction) => void,
  requireCommunityMember: (
    req: Request,
    res: Response,
    next: NextFunction
  ) => void
): Router {
  const router = Router();
  router.use(requireAuth);

  // -- Community events --------------------------------------------------

  router.get(
    "/communities/:communityId/events",
    requireCommunityMember,
    (req, res) => {
      const events = service.listCommunityEvents(
        req.params.communityId,
        req.userId!
      );
      res.json(events);
    }
  );

  router.post(
    "/communities/:communityId/events",
    requireCommunityMember,
    (req, res, next) => {
      try {
        const event = service.createEvent(req.userId!, {
          ...req.body,
          communityId: req.params.communityId,
          visibility: "community",
        });
        res.status(201).json(event);
      } catch (err) {
        next(err);
      }
    }
  );

  // -- Personal events -----------------------------------------------------

  router.get("/users/@me/events", (req, res) => {
    const events = service.listPersonalEvents(req.userId!);
    res.json(events);
  });

  router.post("/users/@me/events", (req, res, next) => {
    try {
      const event = service.createEvent(req.userId!, {
        ...req.body,
        communityId: null,
        visibility: "personal",
      });
      res.status(201).json(event);
    } catch (err) {
      next(err);
    }
  });

  // -- Shared: edit / delete / RSVP ----------------------------------------

  router.patch("/events/:eventId", (req, res, next) => {
    try {
      const event = service.updateEvent(
        req.params.eventId,
        req.userId!,
        req.body
      );
      res.json(event);
    } catch (err) {
      next(err);
    }
  });

  router.delete("/events/:eventId", (req, res, next) => {
    try {
      service.deleteEvent(req.params.eventId, req.userId!);
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  router.put("/events/:eventId/rsvp", (req, res, next) => {
    try {
      const { status } = req.body as { status: "going" | "interested" | "not_going" };
      const rsvp = service.setRsvp(req.params.eventId, req.userId!, status);
      res.json(rsvp);
    } catch (err) {
      next(err);
    }
  });

  router.delete("/events/:eventId/rsvp", (req, res, next) => {
    try {
      service.removeRsvp(req.params.eventId, req.userId!);
      res.status(204).end();
    } catch (err) {
      next(err);
    }
  });

  // -- Error handling --------------------------------------------------------

  router.use(
    (err: unknown, _req: Request, res: Response, _next: NextFunction) => {
      if (err instanceof ValidationError) {
        return res.status(400).json({ error: err.message });
      }
      if (err instanceof ForbiddenError) {
        return res.status(403).json({ error: err.message });
      }
      if (err instanceof NotFoundError) {
        return res.status(404).json({ error: err.message });
      }
      console.error(err);
      res.status(500).json({ error: "internal server error" });
    }
  );

  return router;
}

// Extend Express's Request type with the auth middleware's user id field.
// Remove this if Fluxer already declares it elsewhere.
declare global {
  namespace Express {
    interface Request {
      userId?: string;
    }
  }
}
