// Types for the community Events / Calendar feature.
// Scope: community + personal events, RSVP, basic recurrence.
// Out of scope (see fluxer-meta#3 for full spec): CalDAV export, temporary
// guest accounts for external invitees, mobile client work.

export type EventVisibility = "community" | "personal";

export type EventLocationType = "voice_channel" | "external" | "none";

export type RsvpStatus = "going" | "interested" | "not_going";

export type RecurrenceFrequency = "none" | "daily" | "weekly" | "monthly";

export interface RecurrenceRule {
  frequency: RecurrenceFrequency;
  /** e.g. every 2 weeks -> interval = 2 */
  interval: number;
  /** for weekly: 0 (Sun) - 6 (Sat) */
  byWeekday?: number[];
  /** ISO date string; recurrence stops after this date (inclusive) */
  until?: string;
  /** hard cap so a bad rule can't generate unbounded occurrences */
  count?: number;
}

export interface EventLocation {
  type: EventLocationType;
  /** channel id, when type === "voice_channel" */
  channelId?: string;
  /** free-text address / url, when type === "external" */
  description?: string;
}

export interface CommunityEvent {
  id: string;
  communityId: string | null; // null for personal events
  visibility: EventVisibility;
  creatorId: string;
  title: string;
  description: string;
  location: EventLocation;
  startTime: string; // ISO 8601, in event's stored timezone (UTC)
  endTime: string; // ISO 8601
  recurrence: RecurrenceRule;
  coverImageUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface EventRsvp {
  eventId: string;
  userId: string;
  status: RsvpStatus;
  respondedAt: string;
}

export interface EventWithRsvpSummary extends CommunityEvent {
  rsvpCounts: Record<RsvpStatus, number>;
  /** the requesting user's own RSVP, if any */
  viewerRsvp?: RsvpStatus;
}

export interface CreateEventInput {
  communityId: string | null;
  visibility: EventVisibility;
  title: string;
  description?: string;
  location?: EventLocation;
  startTime: string;
  endTime: string;
  recurrence?: RecurrenceRule;
  coverImageUrl?: string;
}

export interface UpdateEventInput extends Partial<CreateEventInput> {}
