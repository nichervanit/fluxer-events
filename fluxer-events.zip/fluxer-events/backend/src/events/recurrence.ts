import type { CommunityEvent, RecurrenceRule } from "./types";

/** Hard safety cap so a malformed/infinite rule can never generate
 *  unbounded work. Callers should page beyond this via `until`. */
const MAX_OCCURRENCES = 500;

export interface EventOccurrence {
  eventId: string;
  startTime: string;
  endTime: string;
  isFirstOccurrence: boolean;
}

/**
 * Expands a (possibly recurring) event into concrete occurrences
 * within [rangeStart, rangeEnd]. For non-recurring events this
 * returns at most one occurrence.
 */
export function expandOccurrences(
  event: CommunityEvent,
  rangeStart: Date,
  rangeEnd: Date
): EventOccurrence[] {
  const { recurrence } = event;
  const duration =
    new Date(event.endTime).getTime() - new Date(event.startTime).getTime();

  if (recurrence.frequency === "none") {
    const start = new Date(event.startTime);
    if (start >= rangeStart && start <= rangeEnd) {
      return [
        {
          eventId: event.id,
          startTime: event.startTime,
          endTime: event.endTime,
          isFirstOccurrence: true,
        },
      ];
    }
    return [];
  }

  const occurrences: EventOccurrence[] = [];
  const until = recurrence.until ? new Date(recurrence.until) : undefined;
  const hardStop = until && until < rangeEnd ? until : rangeEnd;

  let cursor = new Date(event.startTime);
  let count = 0;
  let generated = 0;

  while (cursor <= hardStop && generated < MAX_OCCURRENCES) {
    if (matchesRule(cursor, event.startTime, recurrence)) {
      count += 1;
      if (recurrence.count && count > recurrence.count) break;

      if (cursor >= rangeStart) {
        const occStart = new Date(cursor);
        const occEnd = new Date(occStart.getTime() + duration);
        occurrences.push({
          eventId: event.id,
          startTime: occStart.toISOString(),
          endTime: occEnd.toISOString(),
          isFirstOccurrence: count === 1,
        });
        generated += 1;
      }
    }
    cursor = advance(cursor, recurrence);
  }

  return occurrences;
}

function matchesRule(
  date: Date,
  originalStart: string,
  rule: RecurrenceRule
): boolean {
  if (rule.frequency === "weekly" && rule.byWeekday?.length) {
    return rule.byWeekday.includes(date.getUTCDay());
  }
  return true;
}

function advance(date: Date, rule: RecurrenceRule): Date {
  const next = new Date(date);
  const interval = Math.max(1, rule.interval || 1);

  switch (rule.frequency) {
    case "daily":
      next.setUTCDate(next.getUTCDate() + interval);
      return next;
    case "weekly":
      // Step one day at a time when specific weekdays are set, so we
      // don't skip days within the same week; otherwise jump by weeks.
      if (rule.byWeekday?.length) {
        next.setUTCDate(next.getUTCDate() + 1);
      } else {
        next.setUTCDate(next.getUTCDate() + 7 * interval);
      }
      return next;
    case "monthly":
      next.setUTCMonth(next.getUTCMonth() + interval);
      return next;
    default:
      // Shouldn't reach here for "none"; guard against infinite loop.
      next.setUTCFullYear(next.getUTCFullYear() + 100);
      return next;
  }
}
