-- Events feature schema (SQLite).
-- Adapt table/column naming to match Fluxer's existing conventions
-- (this assumes snake_case + TEXT ids, matching most Discord-style schemas).

CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  community_id TEXT,               -- NULL for personal events
  visibility TEXT NOT NULL CHECK (visibility IN ('community', 'personal')),
  creator_id TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  location_type TEXT NOT NULL DEFAULT 'none' CHECK (location_type IN ('voice_channel', 'external', 'none')),
  location_channel_id TEXT,
  location_description TEXT,
  start_time TEXT NOT NULL,        -- ISO 8601 UTC
  end_time TEXT NOT NULL,
  recurrence_frequency TEXT NOT NULL DEFAULT 'none' CHECK (recurrence_frequency IN ('none', 'daily', 'weekly', 'monthly')),
  recurrence_interval INTEGER NOT NULL DEFAULT 1,
  recurrence_by_weekday TEXT,      -- JSON array, e.g. "[1,3,5]"
  recurrence_until TEXT,           -- ISO date
  recurrence_count INTEGER,
  cover_image_url TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

  FOREIGN KEY (creator_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_events_community_start
  ON events (community_id, start_time);

CREATE INDEX IF NOT EXISTS idx_events_creator
  ON events (creator_id);

CREATE TABLE IF NOT EXISTS event_rsvps (
  event_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('going', 'interested', 'not_going')),
  responded_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

  PRIMARY KEY (event_id, user_id),
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_rsvps_user
  ON event_rsvps (user_id);
