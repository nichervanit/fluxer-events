import type Database from "better-sqlite3";
import { randomUUID } from "crypto";
import type {
  CommunityEvent,
  CreateEventInput,
  EventRsvp,
  EventWithRsvpSummary,
  RsvpStatus,
  UpdateEventInput,
} from "./types";
import {
  NoopEventsGatewayPublisher,
  type EventsGatewayPublisher,
} from "./gateway/publisher";

/**
 * Thin data-access layer for events. Takes a `better-sqlite3` Database
 * instance so it can be wired into Fluxer's existing DB connection
 * rather than opening its own, plus an optional gateway publisher so
 * mutations push real-time updates (see gateway/publisher.ts — the
 * transport there is a guess and needs adaptation to Fluxer's actual
 * inter-service bus).
 */
export class EventsService {
  constructor(
    private db: Database.Database,
    private publisher: EventsGatewayPublisher = new NoopEventsGatewayPublisher()
  ) {}

  createEvent(creatorId: string, input: CreateEventInput): CommunityEvent {
    if (new Date(input.endTime) <= new Date(input.startTime)) {
      throw new ValidationError("endTime must be after startTime");
    }
    if (!input.title.trim()) {
      throw new ValidationError("title is required");
    }

    const id = randomUUID();
    const now = new Date().toISOString();
    const recurrence = input.recurrence ?? { frequency: "none", interval: 1 };
    const location = input.location ?? { type: "none" };

    this.db
      .prepare(
        `INSERT INTO events (
          id, community_id, visibility, creator_id, title, description,
          location_type, location_channel_id, location_description,
          start_time, end_time,
          recurrence_frequency, recurrence_interval, recurrence_by_weekday,
          recurrence_until, recurrence_count,
          cover_image_url, created_at, updated_at
        ) VALUES (@id, @communityId, @visibility, @creatorId, @title, @description,
          @locationType, @locationChannelId, @locationDescription,
          @startTime, @endTime,
          @recurrenceFrequency, @recurrenceInterval, @recurrenceByWeekday,
          @recurrenceUntil, @recurrenceCount,
          @coverImageUrl, @now, @now)`
      )
      .run({
        id,
        communityId: input.communityId,
        visibility: input.visibility,
        creatorId,
        title: input.title.trim(),
        description: input.description ?? "",
        locationType: location.type,
        locationChannelId: location.channelId ?? null,
        locationDescription: location.description ?? null,
        startTime: input.startTime,
        endTime: input.endTime,
        recurrenceFrequency: recurrence.frequency,
        recurrenceInterval: recurrence.interval,
        recurrenceByWeekday: recurrence.byWeekday
          ? JSON.stringify(recurrence.byWeekday)
          : null,
        recurrenceUntil: recurrence.until ?? null,
        recurrenceCount: recurrence.count ?? null,
        coverImageUrl: input.coverImageUrl ?? null,
        now,
      });

    const created = this.getEventOrThrow(id);
    void this.notifyChange(created, { type: "event_created", event: created });
    return created;
  }

  updateEvent(
    eventId: string,
    requesterId: string,
    input: UpdateEventInput
  ): CommunityEvent {
    const existing = this.getEventOrThrow(eventId);
    if (existing.creatorId !== requesterId) {
      throw new ForbiddenError("only the event creator can edit this event");
    }

    const merged: CreateEventInput = {
      communityId: input.communityId ?? existing.communityId,
      visibility: input.visibility ?? existing.visibility,
      title: input.title ?? existing.title,
      description: input.description ?? existing.description,
      location: input.location ?? existing.location,
      startTime: input.startTime ?? existing.startTime,
      endTime: input.endTime ?? existing.endTime,
      recurrence: input.recurrence ?? existing.recurrence,
      coverImageUrl: input.coverImageUrl ?? existing.coverImageUrl,
    };

    if (new Date(merged.endTime) <= new Date(merged.startTime)) {
      throw new ValidationError("endTime must be after startTime");
    }

    const now = new Date().toISOString();
    this.db
      .prepare(
        `UPDATE events SET
          community_id = @communityId, visibility = @visibility,
          title = @title, description = @description,
          location_type = @locationType, location_channel_id = @locationChannelId,
          location_description = @locationDescription,
          start_time = @startTime, end_time = @endTime,
          recurrence_frequency = @recurrenceFrequency,
          recurrence_interval = @recurrenceInterval,
          recurrence_by_weekday = @recurrenceByWeekday,
          recurrence_until = @recurrenceUntil,
          recurrence_count = @recurrenceCount,
          cover_image_url = @coverImageUrl,
          updated_at = @now
        WHERE id = @id`
      )
      .run({
        id: eventId,
        communityId: merged.communityId,
        visibility: merged.visibility,
        title: merged.title.trim(),
        description: merged.description ?? "",
        locationType: merged.location?.type ?? "none",
        locationChannelId: merged.location?.channelId ?? null,
        locationDescription: merged.location?.description ?? null,
        startTime: merged.startTime,
        endTime: merged.endTime,
        recurrenceFrequency: merged.recurrence?.frequency ?? "none",
        recurrenceInterval: merged.recurrence?.interval ?? 1,
        recurrenceByWeekday: merged.recurrence?.byWeekday
          ? JSON.stringify(merged.recurrence.byWeekday)
          : null,
        recurrenceUntil: merged.recurrence?.until ?? null,
        recurrenceCount: merged.recurrence?.count ?? null,
        coverImageUrl: merged.coverImageUrl ?? null,
        now,
      });

    const updated = this.getEventOrThrow(eventId);
    void this.notifyChange(updated, { type: "event_updated", event: updated });
    return updated;
  }

  deleteEvent(eventId: string, requesterId: string): void {
    const existing = this.getEventOrThrow(eventId);
    if (existing.creatorId !== requesterId) {
      throw new ForbiddenError("only the event creator can delete this event");
    }
    this.db.prepare(`DELETE FROM events WHERE id = ?`).run(eventId);
    void this.notifyChange(existing, { type: "event_deleted", eventId });
  }

  getEvent(eventId: string): CommunityEvent | null {
    const row = this.db
      .prepare(`SELECT * FROM events WHERE id = ?`)
      .get(eventId) as EventRow | undefined;
    return row ? rowToEvent(row) : null;
  }

  private getEventOrThrow(eventId: string): CommunityEvent {
    const event = this.getEvent(eventId);
    if (!event) throw new NotFoundError(`event ${eventId} not found`);
    return event;
  }

  listCommunityEvents(
    communityId: string,
    viewerId: string
  ): EventWithRsvpSummary[] {
    const rows = this.db
      .prepare(
        `SELECT * FROM events WHERE community_id = ? ORDER BY start_time ASC`
      )
      .all(communityId) as EventRow[];
    return rows.map((row) => this.attachRsvpSummary(rowToEvent(row), viewerId));
  }

  listPersonalEvents(userId: string): EventWithRsvpSummary[] {
    const rows = this.db
      .prepare(
        `SELECT * FROM events WHERE visibility = 'personal' AND creator_id = ?
         ORDER BY start_time ASC`
      )
      .all(userId) as EventRow[];
    return rows.map((row) => this.attachRsvpSummary(rowToEvent(row), userId));
  }

  setRsvp(eventId: string, userId: string, status: RsvpStatus): EventRsvp {
    const event = this.getEventOrThrow(eventId); // 404s if missing
    const now = new Date().toISOString();
    this.db
      .prepare(
        `INSERT INTO event_rsvps (event_id, user_id, status, responded_at)
         VALUES (@eventId, @userId, @status, @now)
         ON CONFLICT(event_id, user_id)
         DO UPDATE SET status = @status, responded_at = @now`
      )
      .run({ eventId, userId, status, now });

    const rsvp = { eventId, userId, status, respondedAt: now };
    void this.notifyChange(event, { type: "rsvp_updated", eventId, rsvp });
    return rsvp;
  }

  /** Routes a change notification to the right topic(s) — community
   *  members and/or the acting user's personal-calendar subscribers. */
  private async notifyChange(
    event: CommunityEvent,
    payload: Parameters<EventsGatewayPublisher["publishToCommunity"]>[1]
  ): Promise<void> {
    try {
      if (event.visibility === "community" && event.communityId) {
        await this.publisher.publishToCommunity(event.communityId, payload);
      } else {
        await this.publisher.publishToUser(event.creatorId, payload);
      }
    } catch {
      // Real-time push is a nice-to-have; never let a publish failure
      // fail the underlying mutation, which already succeeded.
    }
  }

  removeRsvp(eventId: string, userId: string): void {
    this.db
      .prepare(`DELETE FROM event_rsvps WHERE event_id = ? AND user_id = ?`)
      .run(eventId, userId);
  }

  private attachRsvpSummary(
    event: CommunityEvent,
    viewerId: string
  ): EventWithRsvpSummary {
    const rows = this.db
      .prepare(`SELECT user_id, status FROM event_rsvps WHERE event_id = ?`)
      .all(event.id) as { user_id: string; status: RsvpStatus }[];

    const rsvpCounts: Record<RsvpStatus, number> = {
      going: 0,
      interested: 0,
      not_going: 0,
    };
    let viewerRsvp: RsvpStatus | undefined;

    for (const row of rows) {
      rsvpCounts[row.status] += 1;
      if (row.user_id === viewerId) viewerRsvp = row.status;
    }

    return { ...event, rsvpCounts, viewerRsvp };
  }
}

export class ValidationError extends Error {}
export class ForbiddenError extends Error {}
export class NotFoundError extends Error {}

interface EventRow {
  id: string;
  community_id: string | null;
  visibility: string;
  creator_id: string;
  title: string;
  description: string;
  location_type: string;
  location_channel_id: string | null;
  location_description: string | null;
  start_time: string;
  end_time: string;
  recurrence_frequency: string;
  recurrence_interval: number;
  recurrence_by_weekday: string | null;
  recurrence_until: string | null;
  recurrence_count: number | null;
  cover_image_url: string | null;
  created_at: string;
  updated_at: string;
}

function rowToEvent(row: EventRow): CommunityEvent {
  return {
    id: row.id,
    communityId: row.community_id,
    visibility: row.visibility as CommunityEvent["visibility"],
    creatorId: row.creator_id,
    title: row.title,
    description: row.description,
    location: {
      type: row.location_type as CommunityEvent["location"]["type"],
      channelId: row.location_channel_id ?? undefined,
      description: row.location_description ?? undefined,
    },
    startTime: row.start_time,
    endTime: row.end_time,
    recurrence: {
      frequency: row.recurrence_frequency as CommunityEvent["recurrence"]["frequency"],
      interval: row.recurrence_interval,
      byWeekday: row.recurrence_by_weekday
        ? JSON.parse(row.recurrence_by_weekday)
        : undefined,
      until: row.recurrence_until ?? undefined,
      count: row.recurrence_count ?? undefined,
    },
    coverImageUrl: row.cover_image_url ?? undefined,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}
