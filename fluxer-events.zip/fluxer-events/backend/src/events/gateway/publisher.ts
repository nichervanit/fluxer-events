/**
 * CAVEAT: I don't know how Fluxer's Node backend and Erlang/OTP gateway
 * actually communicate internally — this could be Redis pub/sub, NATS,
 * RabbitMQ, an internal HTTP push endpoint, or direct distributed-Erlang
 * node connections from Node via a library. Redis pub/sub is the most
 * common glue for a polyglot setup like this, so it's implemented here,
 * but treat `RedisEventsPublisher` as a placeholder to swap for whatever
 * Fluxer's other real-time features (presence, typing indicators,
 * message delivery) already use — reuse *that* mechanism instead of
 * introducing a second one.
 */

export type EventsGatewayEvent =
  | { type: "event_created"; event: unknown }
  | { type: "event_updated"; event: unknown }
  | { type: "event_deleted"; eventId: string }
  | { type: "rsvp_updated"; eventId: string; rsvp: unknown };

export interface EventsGatewayPublisher {
  publishToCommunity(communityId: string, payload: EventsGatewayEvent): Promise<void>;
  publishToUser(userId: string, payload: EventsGatewayEvent): Promise<void>;
}

/** Default no-op so EventsService works even if no publisher is wired up
 *  yet (e.g. during initial integration before the gateway side exists). */
export class NoopEventsGatewayPublisher implements EventsGatewayPublisher {
  async publishToCommunity(): Promise<void> {}
  async publishToUser(): Promise<void> {}
}

/** Example Redis implementation. Requires `ioredis` or similar client
 *  matching whatever Fluxer already uses elsewhere. */
export class RedisEventsGatewayPublisher implements EventsGatewayPublisher {
  constructor(private redisClient: { publish(channel: string, message: string): Promise<number> }) {}

  async publishToCommunity(
    communityId: string,
    payload: EventsGatewayEvent
  ): Promise<void> {
    await this.redisClient.publish(
      `events:community:${communityId}`,
      JSON.stringify(payload)
    );
  }

  async publishToUser(
    userId: string,
    payload: EventsGatewayEvent
  ): Promise<void> {
    await this.redisClient.publish(
      `events:user:${userId}`,
      JSON.stringify(payload)
    );
  }
}
