# Real-time sync — architecture note (read this before wiring in)

I don't have access to Fluxer's actual Erlang/OTP gateway source, so I
can't know its exact internal module structure, PubSub library choice,
or how the Node/TS backend currently talks to it (if at all, for other
features like messages/presence).

What I've written here follows the **standard, most common pattern**
for this kind of split architecture — used by e.g. Phoenix Channels,
Discord's own gateway, and most "Node API + separate realtime process"
systems:

```
Client (React) --WebSocket--> Erlang/OTP Gateway --subscribes to--> Redis Pub/Sub
                                                                          ^
Node/TS backend --publishes to-- Redis Pub/Sub (on event create/update/delete/RSVP)
```

**This assumes Fluxer already uses Redis (or similar) as the bridge
between the Node backend and the Erlang gateway for other real-time
features (message send, presence, typing indicators).** That's true
for the overwhelming majority of systems built this way — a
Node backend and a separate Erlang/OTP realtime process essentially
always need *some* shared bus between them, since they don't share
memory, and Redis Pub/Sub is the near-universal choice for this.

**If instead Fluxer's Node backend calls directly into the Erlang
gateway via HTTP, gRPC, or Erlang distribution protocol (i.e. Node
talks to Erlang directly, no Redis)** — swap `RedisEventPublisher` in
`event-publisher.ts` for whatever that mechanism is. The `EventPublisher`
interface is deliberately small (one `publish` method) so this swap
should be contained to one file.

**Please verify which of these is actually true before wiring this in**
— ask a maintainer directly, or grep the existing codebase for how
message-send events currently reach the gateway. Building against the
wrong assumption here would mean this doesn't work at all, not just
work imperfectly.
