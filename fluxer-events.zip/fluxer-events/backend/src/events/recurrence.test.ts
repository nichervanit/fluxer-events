import { describe, it, expect } from "vitest";
import { expandOccurrences } from "./recurrence";
import type { CommunityEvent } from "./types";

function makeEvent(overrides: Partial<CommunityEvent> = {}): CommunityEvent {
  return {
    id: "evt_1",
    communityId: "com_1",
    visibility: "community",
    creatorId: "user_1",
    title: "Weekly standup",
    description: "",
    location: { type: "none" },
    startTime: "2026-07-06T18:00:00.000Z", // a Monday
    endTime: "2026-07-06T18:30:00.000Z",
    recurrence: { frequency: "none", interval: 1 },
    createdAt: "2026-07-01T00:00:00.000Z",
    updatedAt: "2026-07-01T00:00:00.000Z",
    ...overrides,
  };
}

describe("expandOccurrences", () => {
  it("returns a single occurrence for a non-recurring event in range", () => {
    const event = makeEvent();
    const result = expandOccurrences(
      event,
      new Date("2026-07-01"),
      new Date("2026-07-31")
    );
    expect(result).toHaveLength(1);
    expect(result[0].startTime).toBe(event.startTime);
  });

  it("excludes a non-recurring event outside the range", () => {
    const event = makeEvent();
    const result = expandOccurrences(
      event,
      new Date("2026-08-01"),
      new Date("2026-08-31")
    );
    expect(result).toHaveLength(0);
  });

  it("expands a weekly recurrence across a month", () => {
    const event = makeEvent({
      recurrence: { frequency: "weekly", interval: 1 },
    });
    const result = expandOccurrences(
      event,
      new Date("2026-07-01"),
      new Date("2026-07-31")
    );
    // Mondays in July 2026 starting the 6th: 6, 13, 20, 27
    expect(result).toHaveLength(4);
    expect(result.map((o) => o.startTime.slice(0, 10))).toEqual([
      "2026-07-06",
      "2026-07-13",
      "2026-07-20",
      "2026-07-27",
    ]);
  });

  it("respects byWeekday for multi-day weekly recurrence", () => {
    const event = makeEvent({
      startTime: "2026-07-06T18:00:00.000Z", // Monday
      endTime: "2026-07-06T18:30:00.000Z",
      recurrence: { frequency: "weekly", interval: 1, byWeekday: [1, 3, 5] }, // Mon/Wed/Fri
    });
    const result = expandOccurrences(
      event,
      new Date("2026-07-06"),
      new Date("2026-07-12")
    );
    // Mon 6, Wed 8, Fri 10
    expect(result.map((o) => o.startTime.slice(0, 10))).toEqual([
      "2026-07-06",
      "2026-07-08",
      "2026-07-10",
    ]);
  });

  it("stops at recurrence.until", () => {
    const event = makeEvent({
      recurrence: {
        frequency: "weekly",
        interval: 1,
        until: "2026-07-14T00:00:00.000Z",
      },
    });
    const result = expandOccurrences(
      event,
      new Date("2026-07-01"),
      new Date("2026-08-31")
    );
    expect(result).toHaveLength(2); // July 6, July 13
  });

  it("stops at recurrence.count", () => {
    const event = makeEvent({
      recurrence: { frequency: "daily", interval: 1, count: 3 },
    });
    const result = expandOccurrences(
      event,
      new Date("2026-07-01"),
      new Date("2026-12-31")
    );
    expect(result).toHaveLength(3);
  });

  it("handles monthly recurrence", () => {
    const event = makeEvent({
      startTime: "2026-01-15T18:00:00.000Z",
      endTime: "2026-01-15T19:00:00.000Z",
      recurrence: { frequency: "monthly", interval: 1 },
    });
    const result = expandOccurrences(
      event,
      new Date("2026-01-01"),
      new Date("2026-04-30")
    );
    expect(result.map((o) => o.startTime.slice(0, 10))).toEqual([
      "2026-01-15",
      "2026-02-15",
      "2026-03-15",
      "2026-04-15",
    ]);
  });

  it("never exceeds the hard safety cap even with a runaway rule", () => {
    const event = makeEvent({
      recurrence: { frequency: "daily", interval: 1 },
    });
    const result = expandOccurrences(
      event,
      new Date("2000-01-01"),
      new Date("2100-01-01") // absurdly wide range
    );
    expect(result.length).toBeLessThanOrEqual(500);
  });
});
