import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/event_models.dart';

/// CAVEAT: I don't know what state management flutter_client actually uses
/// (Provider / Riverpod / Bloc / GetX are all common in Flutter apps this
/// size). `ChangeNotifier` is part of Flutter's SDK itself (not a third-
/// party package), so this works standalone or slots into Provider with
/// zero changes — but if the app uses Riverpod or Bloc elsewhere, port
/// this controller's logic into that pattern instead of introducing a
/// second state-management approach.
class EventsController extends ChangeNotifier {
  final String baseUrl; // e.g. https://fluxer.app/api — inject the real one
  final String? communityId; // null => personal calendar
  final String viewerId; // the signed-in user's own id
  final http.Client _http;
  final Future<String?> Function() getAuthToken; // adapt to real auth storage

  List<CommunityEvent> events = [];
  bool isLoading = true;
  String? error;

  StreamSubscription? _gatewaySubscription;

  EventsController({
    required this.baseUrl,
    required this.getAuthToken,
    required this.viewerId,
    this.communityId,
    http.Client? httpClient,
  }) : _http = httpClient ?? http.Client();

  String get _eventsUrl => communityId != null
      ? '$baseUrl/communities/$communityId/events'
      : '$baseUrl/users/@me/events';

  Future<Map<String, String>> _authHeaders() async {
    final token = await getAuthToken();
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  Future<void> load() async {
    try {
      error = null;
      final res = await _http.get(Uri.parse(_eventsUrl), headers: await _authHeaders());
      if (res.statusCode != 200) {
        throw Exception('failed to load events (${res.statusCode})');
      }
      final decoded = jsonDecode(res.body) as List;
      events = decoded
          .map((e) => CommunityEvent.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      error = 'Couldn\'t load events. Pull to refresh to try again.';
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> setRsvp(String eventId, RsvpStatus status) async {
    final index = events.indexWhere((e) => e.id == eventId);
    if (index == -1) return;

    final previous = events[index];
    // Optimistic update.
    events[index] = previous.copyWith(
      viewerRsvp: status,
      rsvpCounts: _recomputeCounts(previous, status),
    );
    notifyListeners();

    try {
      final res = await _http.put(
        Uri.parse('$baseUrl/events/$eventId/rsvp'),
        headers: await _authHeaders(),
        body: jsonEncode({'status': rsvpStatusToJson(status)}),
      );
      if (res.statusCode != 200) throw Exception('rsvp failed');
    } catch (e) {
      events[index] = previous; // roll back
      error = 'Couldn\'t update your RSVP — try again.';
      notifyListeners();
    }
  }

  Map<String, int> _recomputeCounts(CommunityEvent event, RsvpStatus newStatus) {
    final counts = Map<String, int>.from(event.rsvpCounts);
    if (event.viewerRsvp != null) {
      final oldKey = rsvpStatusToJson(event.viewerRsvp!);
      counts[oldKey] = (counts[oldKey] ?? 0) - 1;
      if (counts[oldKey]! < 0) counts[oldKey] = 0;
    }
    final newKey = rsvpStatusToJson(newStatus);
    counts[newKey] = (counts[newKey] ?? 0) + 1;
    return counts;
  }

  /// Wire this to whatever real-time gateway connection flutter_client
  /// already maintains (adapt the message shape to match the actual
  /// wire format — see gateway/publisher.ts on the backend side for
  /// the payload this assumes).
  void attachGatewayStream(Stream<Map<String, dynamic>> gatewayMessages) {
    _gatewaySubscription?.cancel();
    _gatewaySubscription = gatewayMessages.listen((message) {
      switch (message['type']) {
        case 'event_created':
          events = [...events, CommunityEvent.fromJson(message['event'])];
          break;
        case 'event_updated':
          final updated = CommunityEvent.fromJson(message['event']);
          events = events.map((e) => e.id == updated.id ? updated : e).toList();
          break;
        case 'event_deleted':
          events = events.where((e) => e.id != message['eventId']).toList();
          break;
        case 'rsvp_updated':
          final eventId = message['eventId'] as String;
          final rsvpUserId = message['rsvp']['userId'] as String;
          final idx = events.indexWhere((e) => e.id == eventId);
          if (idx != -1) {
            final status = rsvpStatusFromJson(message['rsvp']['status']);
            if (rsvpUserId == viewerId) {
              // Our own change — we know our true previous status
              // (viewerRsvp), so the local math is exact here.
              events[idx] = events[idx].copyWith(
                viewerRsvp: status,
                rsvpCounts: _recomputeCounts(events[idx], status),
              );
            } else {
              // Someone else's RSVP changed. We don't know their prior
              // status from this message alone, so we can't safely
              // adjust counts locally without risking drift — reload
              // this list from the server instead of guessing.
              load();
            }
          }
          break;
      }
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _gatewaySubscription?.cancel();
    _http.close();
    super.dispose();
  }
}
