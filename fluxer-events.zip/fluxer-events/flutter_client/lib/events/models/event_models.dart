// Mirrors backend/src/events/types.ts. Keep these in sync manually
// (or generate from an OpenAPI/JSON-schema spec if Fluxer has one —
// I don't know if it does).

enum EventVisibility { community, personal }

enum RsvpStatus { going, interested, notGoing }

enum RecurrenceFrequency { none, daily, weekly, monthly }

RsvpStatus rsvpStatusFromJson(String value) {
  switch (value) {
    case 'going':
      return RsvpStatus.going;
    case 'interested':
      return RsvpStatus.interested;
    case 'not_going':
      return RsvpStatus.notGoing;
    default:
      throw ArgumentError('Unknown RSVP status: $value');
  }
}

String rsvpStatusToJson(RsvpStatus status) {
  switch (status) {
    case RsvpStatus.going:
      return 'going';
    case RsvpStatus.interested:
      return 'interested';
    case RsvpStatus.notGoing:
      return 'not_going';
  }
}

class EventLocation {
  final String type; // 'voice_channel' | 'external' | 'none'
  final String? channelId;
  final String? description;

  EventLocation({required this.type, this.channelId, this.description});

  factory EventLocation.fromJson(Map<String, dynamic> json) {
    return EventLocation(
      type: json['type'] as String,
      channelId: json['channelId'] as String?,
      description: json['description'] as String?,
    );
  }
}

class RecurrenceRule {
  final String frequency; // 'none' | 'daily' | 'weekly' | 'monthly'
  final int interval;
  final List<int>? byWeekday;
  final String? until;
  final int? count;

  RecurrenceRule({
    required this.frequency,
    required this.interval,
    this.byWeekday,
    this.until,
    this.count,
  });

  factory RecurrenceRule.fromJson(Map<String, dynamic> json) {
    return RecurrenceRule(
      frequency: json['frequency'] as String,
      interval: json['interval'] as int? ?? 1,
      byWeekday: (json['byWeekday'] as List?)?.map((e) => e as int).toList(),
      until: json['until'] as String?,
      count: json['count'] as int?,
    );
  }
}

class CommunityEvent {
  final String id;
  final String? communityId;
  final String visibility;
  final String creatorId;
  final String title;
  final String description;
  final EventLocation location;
  final DateTime startTime;
  final DateTime endTime;
  final RecurrenceRule recurrence;
  final String? coverImageUrl;
  final Map<String, int> rsvpCounts; // keys: going, interested, not_going
  final RsvpStatus? viewerRsvp;

  CommunityEvent({
    required this.id,
    required this.communityId,
    required this.visibility,
    required this.creatorId,
    required this.title,
    required this.description,
    required this.location,
    required this.startTime,
    required this.endTime,
    required this.recurrence,
    this.coverImageUrl,
    required this.rsvpCounts,
    this.viewerRsvp,
  });

  factory CommunityEvent.fromJson(Map<String, dynamic> json) {
    return CommunityEvent(
      id: json['id'] as String,
      communityId: json['communityId'] as String?,
      visibility: json['visibility'] as String,
      creatorId: json['creatorId'] as String,
      title: json['title'] as String,
      description: json['description'] as String? ?? '',
      location: EventLocation.fromJson(
          json['location'] as Map<String, dynamic>? ?? {'type': 'none'}),
      startTime: DateTime.parse(json['startTime'] as String),
      endTime: DateTime.parse(json['endTime'] as String),
      recurrence: RecurrenceRule.fromJson(
          json['recurrence'] as Map<String, dynamic>? ??
              {'frequency': 'none', 'interval': 1}),
      coverImageUrl: json['coverImageUrl'] as String?,
      rsvpCounts: Map<String, int>.from(json['rsvpCounts'] as Map? ??
          {'going': 0, 'interested': 0, 'not_going': 0}),
      viewerRsvp: json['viewerRsvp'] != null
          ? rsvpStatusFromJson(json['viewerRsvp'] as String)
          : null,
    );
  }

  CommunityEvent copyWith({
    Map<String, int>? rsvpCounts,
    RsvpStatus? viewerRsvp,
  }) {
    return CommunityEvent(
      id: id,
      communityId: communityId,
      visibility: visibility,
      creatorId: creatorId,
      title: title,
      description: description,
      location: location,
      startTime: startTime,
      endTime: endTime,
      recurrence: recurrence,
      coverImageUrl: coverImageUrl,
      rsvpCounts: rsvpCounts ?? this.rsvpCounts,
      viewerRsvp: viewerRsvp ?? this.viewerRsvp,
    );
  }
}
