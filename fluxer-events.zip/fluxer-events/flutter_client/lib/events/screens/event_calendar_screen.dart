import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/event_models.dart';
import '../services/events_controller.dart';

/// CAVEAT: uses `provider` for wiring since EventsController extends
/// ChangeNotifier — if flutter_client uses Riverpod/Bloc elsewhere,
/// swap the `ChangeNotifierProvider`/`context.watch` calls for the
/// equivalent in that framework; the widget tree below doesn't care
/// which DI approach hands it an EventsController.
///
/// Visual style deliberately kept close to Material defaults rather
/// than guessing at Fluxer's actual design system (colors, type scale,
/// spacing tokens) — reskin using the app's real theme before merging.
class EventCalendarScreen extends StatefulWidget {
  final String baseUrl;
  final String? communityId;
  final String viewerId;
  final Future<String?> Function() getAuthToken;

  const EventCalendarScreen({
    super.key,
    required this.baseUrl,
    required this.viewerId,
    required this.getAuthToken,
    this.communityId,
  });

  @override
  State<EventCalendarScreen> createState() => _EventCalendarScreenState();
}

class _EventCalendarScreenState extends State<EventCalendarScreen> {
  late final EventsController _controller;
  late DateTime _monthCursor;

  @override
  void initState() {
    super.initState();
    _monthCursor = DateTime(DateTime.now().year, DateTime.now().month, 1);
    _controller = EventsController(
      baseUrl: widget.baseUrl,
      communityId: widget.communityId,
      viewerId: widget.viewerId,
      getAuthToken: widget.getAuthToken,
    );
    _controller.load();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _controller,
      child: Scaffold(
        appBar: AppBar(
          title: Text(_monthLabel(_monthCursor)),
          actions: [
            IconButton(
              icon: const Icon(Icons.chevron_left),
              onPressed: () => setState(() {
                _monthCursor = DateTime(_monthCursor.year, _monthCursor.month - 1, 1);
              }),
            ),
            IconButton(
              icon: const Icon(Icons.today),
              onPressed: () => setState(() {
                _monthCursor = DateTime(DateTime.now().year, DateTime.now().month, 1);
              }),
            ),
            IconButton(
              icon: const Icon(Icons.chevron_right),
              onPressed: () => setState(() {
                _monthCursor = DateTime(_monthCursor.year, _monthCursor.month + 1, 1);
              }),
            ),
          ],
        ),
        body: Consumer<EventsController>(
          builder: (context, controller, _) {
            if (controller.isLoading) {
              return const Center(child: CircularProgressIndicator());
            }

            return RefreshIndicator(
              onRefresh: controller.load,
              child: Column(
                children: [
                  if (controller.error != null)
                    Container(
                      width: double.infinity,
                      color: Theme.of(context).colorScheme.errorContainer,
                      padding: const EdgeInsets.all(8),
                      child: Text(
                        controller.error!,
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onErrorContainer,
                        ),
                      ),
                    ),
                  _MonthGrid(
                    monthCursor: _monthCursor,
                    events: controller.events,
                    onSelectEvent: (event) => _showEventSheet(context, event),
                  ),
                  if (controller.events.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'No events yet. Create one to get this calendar going.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void _showEventSheet(BuildContext context, CommunityEvent event) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => _EventDetailSheet(
        event: event,
        onRsvp: (status) => _controller.setRsvp(event.id, status),
      ),
    );
  }

  String _monthLabel(DateTime date) {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December',
    ];
    return '${months[date.month - 1]} ${date.year}';
  }
}

class _MonthGrid extends StatelessWidget {
  final DateTime monthCursor;
  final List<CommunityEvent> events;
  final void Function(CommunityEvent) onSelectEvent;

  const _MonthGrid({
    required this.monthCursor,
    required this.events,
    required this.onSelectEvent,
  });

  @override
  Widget build(BuildContext context) {
    final days = _buildMonthGrid(monthCursor);
    final eventsByDay = _groupByDay(events);
    const weekdayLabels = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

    return Column(
      children: [
        Row(
          children: weekdayLabels
              .map((label) => Expanded(
                    child: Center(
                      child: Text(
                        label,
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                    ),
                  ))
              .toList(),
        ),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: days.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 7,
            childAspectRatio: 0.85,
          ),
          itemBuilder: (context, index) {
            final day = days[index];
            final key = _dayKey(day.date);
            final dayEvents = eventsByDay[key] ?? [];
            final isToday = _dayKey(DateTime.now()) == key;

            return Container(
              margin: const EdgeInsets.all(1),
              decoration: BoxDecoration(
                border: Border.all(color: Theme.of(context).dividerColor),
                color: day.isCurrentMonth
                    ? Theme.of(context).colorScheme.surface
                    : Theme.of(context).colorScheme.surfaceContainerLowest,
              ),
              padding: const EdgeInsets.all(2),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      width: 20,
                      height: 20,
                      decoration: isToday
                          ? BoxDecoration(
                              color: Theme.of(context).colorScheme.primary,
                              shape: BoxShape.circle,
                            )
                          : null,
                      alignment: Alignment.center,
                      child: Text(
                        '${day.date.day}',
                        style: TextStyle(
                          fontSize: 11,
                          color: isToday
                              ? Theme.of(context).colorScheme.onPrimary
                              : day.isCurrentMonth
                                  ? null
                                  : Theme.of(context).disabledColor,
                        ),
                      ),
                    ),
                  ),
                  ...dayEvents.take(2).map(
                        (event) => GestureDetector(
                          onTap: () => onSelectEvent(event),
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 1),
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: Theme.of(context)
                                  .colorScheme
                                  .primaryContainer,
                              borderRadius: BorderRadius.circular(2),
                            ),
                            child: Text(
                              event.title,
                              style: const TextStyle(fontSize: 8),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ),
                  if (dayEvents.length > 2)
                    Text('+${dayEvents.length - 2}',
                        style: const TextStyle(fontSize: 8)),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  List<_GridDay> _buildMonthGrid(DateTime monthStart) {
    final firstWeekday = monthStart.weekday % 7; // Dart: Mon=1..Sun=7 -> Sun=0
    final gridStart = monthStart.subtract(Duration(days: firstWeekday));
    return List.generate(42, (i) {
      final date = gridStart.add(Duration(days: i));
      return _GridDay(date: date, isCurrentMonth: date.month == monthStart.month);
    });
  }

  Map<String, List<CommunityEvent>> _groupByDay(List<CommunityEvent> events) {
    final map = <String, List<CommunityEvent>>{};
    for (final event in events) {
      final key = _dayKey(event.startTime);
      map.putIfAbsent(key, () => []).add(event);
    }
    return map;
  }

  String _dayKey(DateTime date) => '${date.year}-${date.month}-${date.day}';
}

class _GridDay {
  final DateTime date;
  final bool isCurrentMonth;
  _GridDay({required this.date, required this.isCurrentMonth});
}

class _EventDetailSheet extends StatelessWidget {
  final CommunityEvent event;
  final void Function(RsvpStatus) onRsvp;

  const _EventDetailSheet({required this.event, required this.onRsvp});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(event.title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 4),
          Text(
            '${_formatDateTime(event.startTime)} – ${_formatTime(event.endTime)}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          if (event.description.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(event.description),
          ],
          const SizedBox(height: 16),
          Row(
            children: [
              Text('${event.rsvpCounts['going'] ?? 0} going'),
              const SizedBox(width: 12),
              Text('${event.rsvpCounts['interested'] ?? 0} interested'),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _rsvpButton(context, 'Going', RsvpStatus.going),
              const SizedBox(width: 8),
              _rsvpButton(context, 'Interested', RsvpStatus.interested),
              const SizedBox(width: 8),
              _rsvpButton(context, "Can't go", RsvpStatus.notGoing),
            ],
          ),
        ],
      ),
    );
  }

  Widget _rsvpButton(BuildContext context, String label, RsvpStatus status) {
    final isActive = event.viewerRsvp == status;
    return Expanded(
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          backgroundColor: isActive
              ? Theme.of(context).colorScheme.primaryContainer
              : null,
        ),
        onPressed: () {
          onRsvp(status);
          Navigator.of(context).pop();
        },
        child: Text(label, style: const TextStyle(fontSize: 12)),
      ),
    );
  }

  String _formatDateTime(DateTime date) {
    const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    final hour = date.hour % 12 == 0 ? 12 : date.hour % 12;
    final minute = date.minute.toString().padLeft(2, '0');
    final period = date.hour >= 12 ? 'PM' : 'AM';
    return '${weekdays[date.weekday - 1]}, ${months[date.month - 1]} ${date.day} · $hour:$minute $period';
  }

  String _formatTime(DateTime date) {
    final hour = date.hour % 12 == 0 ? 12 : date.hour % 12;
    final minute = date.minute.toString().padLeft(2, '0');
    final period = date.hour >= 12 ? 'PM' : 'AM';
    return '$hour:$minute $period';
  }
}
