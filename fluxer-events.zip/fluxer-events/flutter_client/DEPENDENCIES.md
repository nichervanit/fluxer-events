# Dependencies this Flutter code assumes

Add to `pubspec.yaml` if not already present:

```yaml
dependencies:
  provider: ^6.0.0   # only if flutter_client doesn't already use
                      # Riverpod/Bloc — see caveat in events_controller.dart
  http: ^1.0.0        # only if flutter_client doesn't already have its
                      # own API client wrapper — if it does, port
                      # EventsController's requests to use that instead
                      # of raw `http` package calls
```

Check `flutter_client/pubspec.yaml` for existing equivalents before adding
either — duplicating an HTTP client or state-management library that
already exists elsewhere in the app is exactly the kind of thing that
gets a PR bounced in review.
