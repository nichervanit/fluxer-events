# Fluxer Events / Calendar — fluxer-meta#3

Updated to address all three gaps flagged as blocking full bounty payout:
mobile support, real-time sync, and calendar (ICS feed) integration.

## What's included

**Backend** (`backend/src/events/`)
- Community + personal events: create/edit/delete (creator-only), RSVP
- Recurrence: daily/weekly (optional specific weekdays)/monthly, with
  `until` or `count` limits — unit-tested, 8 cases covering edge behavior
- SQLite schema, Express routes, validated service layer
- **CalDAV/ICS feed** (`caldav/`): subscribable `.ics` URLs for Apple/Google/
  Outlook calendar — see the scoping note in `caldav/ics.ts` on why this
  is feed-subscription (RFC 5545) rather than full read/write CalDAV
  (RFC 4791), and why that's the right call for v1
- **Real-time gateway bridge** (`gateway/`): Node publishes mutations to
  Redis; see below for what's assumed vs. verified

**Frontend** (`frontend/src/`)
- Month-grid calendar, event detail modal, RSVP
- `useEvents` hook: fetch-on-mount + optional live updates via a gateway
  socket, with optimistic RSVP and a fix for a counting bug (see below)

**Erlang gateway** (`gateway/src/`)
- `fluxer_events_pubsub.erl`: `pg`-based topic broadcast (OTP's built-in
  process groups) — the standard, correct primitive for this
- `fluxer_events_redis_bridge.erl`: subscribes to Redis, forwards to the
  pg broadcast — the missing link between Node's publish and the gateway

**Flutter mobile client** (`flutter_client/lib/events/`)
- `event_models.dart`, `events_controller.dart` (state + API calls),
  `event_calendar_screen.dart` (month grid + RSVP bottom sheet)

## What I actually verified vs. what's a documented assumption

I don't have access to the real `fluxerapp/fluxer` repo, its Erlang
gateway internals, or the Flutter client's existing patterns, and my
sandbox can't compile Erlang or Dart, or install npm/pub packages
(no network access). Given that, here's the honest split:

**Verified by direct execution** (I ran these, not just read them):
- Recurrence engine: 8 cases (weekly, specific weekdays, until, count,
  monthly, runaway-rule safety cap)
- Month-grid date math (both the TS and the Dart weekday-conversion
  formula — Dart's weekday is Mon=1..Sun=7, unlike JS's Sun=0..Sat=6,
  and I checked the conversion against all 7 days)
- ICS feed structure: RFC 5545 line-folding round-trips correctly,
  RRULE generation matches expected output for every recurrence type
- Feed-token signing: tamper detection, expiry, wrong-secret rejection

**Read carefully but NOT executable-verified** (no Erlang/Dart toolchain
available here):
- fluxer_events_pubsub.erl and fluxer_events_redis_bridge.erl — I
  traced the syntax by hand (clause structure, exports matching
  definitions, case/try blocks) but never compiled them. Run them
  through rebar3 compile or equivalent before trusting them.
- The Flutter screen/controller — same caveat, no flutter analyze or
  dart compile was run.

**Explicit architectural assumptions that need maintainer confirmation
before this is wired in for real:**
1. Node <-> Erlang gateway communication goes through Redis pub/sub. This
   is the standard pattern for this kind of split architecture, but if
   Fluxer's other real-time features (presence, typing) use something
   else — direct HTTP, distributed Erlang, NATS — swap it there instead
   of adding a second inter-process mechanism. See
   backend/src/events/gateway/ARCHITECTURE_ASSUMPTION.md.
2. The gateway already has eredis as a dependency, or something
   equivalent — flagged in fluxer_events_redis_bridge.erl.
3. flutter_client doesn't already have its own state-management
   convention (Riverpod/Bloc) that this should be ported into instead of
   using bare ChangeNotifier+provider.

## Two real bugs I caught and fixed during this pass

Both the web (useEvents.ts) and mobile (events_controller.dart)
real-time handlers originally recomputed RSVP counts by assuming any
incoming rsvp_updated message was about the *viewer's own* status
change — using the viewer's previously-known status as the "old" value
to subtract. That's only correct when the message actually is about the
viewer. For anyone else's RSVP change, the client doesn't know their
prior status, so the count math would silently drift wrong over time
(e.g. double-decrementing "going"). Fixed by applying the exact math only
for the viewer's own change and refetching for everyone else's — slightly
less "instant" for other people's RSVPs, correct always.

There was also a topic-name mismatch: the web client subscribed to the
literal string events:user:@me, while the server publishes to
events:user:<actual-user-id> — meaning personal-calendar real-time
updates would have silently never fired. Fixed by requiring a viewerId
prop through the whole chain.

## Before you submit

1. **Comment on fluxer-meta#3 first**, linking this implementation and
   explicitly naming the three assumptions above (Redis, eredis, no
   existing Flutter state pattern) — ask maintainers to confirm or
   correct them before you spend time debugging integration issues that
   might just be wrong assumptions.
2. **Compile everything for real** — rebar3 compile (or whatever
   Fluxer's Erlang build uses) and flutter analyze before opening a
   PR. Neither has been run; I have no way to run them here.
3. **Load-test the Redis bridge** if community sizes are large — a
   community with thousands of members all in one pg group means one
   broadcast/2 call fans out to thousands of sends; ask whether
   that's fine or whether it needs batching/backpressure given Fluxer's
   actual scale.
4. Full read/write CalDAV, if actually required (re-check with
   maintainers — most users just want feed subscription), is still not
   built. It's a materially bigger, separate piece of work.

Nothing here is "guaranteed to pass review." It's now a complete,
internally-consistent attempt at all three gaps, with the parts I could
verify actually verified rather than assumed.
