import { useCallback, useEffect, useState } from "react";
import type { CommunityEvent, RsvpStatus } from "../components/events/types";

interface UseEventsOptions {
  communityId?: string; // omit for personal events
  /** The signed-in viewer's own user id — required to build the correct
   *  personal-calendar subscription topic (`events:user:<id>`) and to
   *  tell "my RSVP changed" apart from "someone else's RSVP changed". */
  viewerId: string;
  /**
   * The gateway's existing WebSocket connection/client, if Fluxer already
   * has one shared across the app (it should — reuse it rather than
   * opening a second socket). Shape here is a guess: adapt `send`/
   * `onMessage` to whatever the real client actually exposes.
   */
  gatewaySocket?: {
    send(message: unknown): void;
    onMessage(handler: (message: unknown) => void): () => void; // returns unsubscribe
  };
}

interface GatewayEventMessage {
  type: "event_created" | "event_updated" | "event_deleted" | "rsvp_updated";
  event?: CommunityEvent;
  eventId?: string;
  rsvp?: { userId: string; status: RsvpStatus };
}

/**
 * Fetches events for a community (or the viewer's personal calendar) and
 * exposes RSVP mutation with optimistic updates.
 *
 * Real-time: if `gatewaySocket` is provided, this subscribes to the
 * community/user topic on mount and merges incoming pushes into state,
 * so multiple members see RSVP/edits live instead of on next refresh.
 * Without a socket, it falls back to fetch-on-mount only — still correct,
 * just not live. CAVEAT: the socket shape here is invented; wire in
 * whatever real client Fluxer's frontend already uses for presence/
 * typing-indicator style features, matching its actual message format.
 */
export function useEvents({ communityId, viewerId, gatewaySocket }: UseEventsOptions) {
  const [events, setEvents] = useState<CommunityEvent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const url = communityId
    ? `/api/communities/${communityId}/events`
    : `/api/users/@me/events`;

  const refetch = useCallback(async () => {
    try {
      setError(null);
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error(`failed to load events (${res.status})`);
      const data: CommunityEvent[] = await res.json();
      setEvents(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "failed to load events");
    } finally {
      setIsLoading(false);
    }
  }, [url]);

  useEffect(() => {
    refetch();
  }, [refetch]);

  useEffect(() => {
    if (!gatewaySocket) return;

    const topic = communityId
      ? `events:community:${communityId}`
      : `events:user:${viewerId}`;
    gatewaySocket.send({ op: "subscribe", topic });

    const unsubscribe = gatewaySocket.onMessage((raw) => {
      const message = raw as GatewayEventMessage;
      setEvents((current) => applyGatewayMessage(current, message, viewerId, refetch));
    });

    return () => {
      gatewaySocket.send({ op: "unsubscribe", topic });
      unsubscribe();
    };
  }, [communityId, viewerId, gatewaySocket, refetch]);

  const setRsvp = useCallback(
    async (eventId: string, status: RsvpStatus) => {
      const previous = events;
      // Optimistic update so the UI feels instant.
      setEvents((current) =>
        current.map((event) =>
          event.id === eventId
            ? {
                ...event,
                viewerRsvp: status,
                rsvpCounts: recomputeCounts(event, status),
              }
            : event
        )
      );

      try {
        const res = await fetch(`/api/events/${eventId}/rsvp`, {
          method: "PUT",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status }),
        });
        if (!res.ok) throw new Error("rsvp failed");
      } catch (err) {
        setEvents(previous); // roll back on failure
        setError("couldn't update your RSVP — try again");
      }
    },
    [events]
  );

  return { events, isLoading, error, refetch, setRsvp };
}

/**
 * Merges an incoming gateway push into local state.
 *
 * For `rsvp_updated`: we only know the *new* status of whichever user
 * changed it, not their previous status — so we can't correctly bump
 * `rsvpCounts` locally for anyone except the viewer themself (whose
 * previous status we already have as `viewerRsvp`). For any other
 * user's RSVP change, guessing at count deltas risks drifting the
 * displayed counts out of sync with reality (e.g. double-decrementing
 * "going" if two members change status close together). So: apply the
 * optimistic local math only when it's the viewer's own change, and
 * fall back to a targeted refetch for everyone else's — correctness
 * over the appearance of a slightly faster update.
 */
function applyGatewayMessage(
  events: CommunityEvent[],
  message: GatewayEventMessage,
  viewerId: string,
  refetch: () => void
): CommunityEvent[] {
  switch (message.type) {
    case "event_created":
      return message.event ? [...events, message.event] : events;

    case "event_updated":
      return message.event
        ? events.map((e) => (e.id === message.event!.id ? message.event! : e))
        : events;

    case "event_deleted":
      return events.filter((e) => e.id !== message.eventId);

    case "rsvp_updated": {
      if (!message.eventId || !message.rsvp) return events;

      if (message.rsvp.userId === viewerId) {
        // Our own change — we already know our previous status
        // (viewerRsvp), so the local math is exact, not a guess.
        return events.map((e) =>
          e.id === message.eventId
            ? {
                ...e,
                viewerRsvp: message.rsvp!.status,
                rsvpCounts: recomputeCounts(e, message.rsvp!.status),
              }
            : e
        );
      }

      // Someone else's change — we don't know their prior status, so
      // don't guess at the count delta. Refetch to get the server's
      // authoritative counts instead.
      refetch();
      return events;
    }

    default:
      return events;
  }
}

function recomputeCounts(
  event: CommunityEvent,
  newStatus: RsvpStatus
): CommunityEvent["rsvpCounts"] {
  const counts = { ...event.rsvpCounts };
  if (event.viewerRsvp) counts[event.viewerRsvp] = Math.max(0, counts[event.viewerRsvp] - 1);
  counts[newStatus] = (counts[newStatus] ?? 0) + 1;
  return counts;
}
