export type RsvpStatus = "going" | "interested" | "not_going";

export interface EventLocation {
  type: "voice_channel" | "external" | "none";
  channelId?: string;
  description?: string;
}

export interface RecurrenceRule {
  frequency: "none" | "daily" | "weekly" | "monthly";
  interval: number;
  byWeekday?: number[];
  until?: string;
  count?: number;
}

export interface CommunityEvent {
  id: string;
  communityId: string | null;
  visibility: "community" | "personal";
  creatorId: string;
  title: string;
  description: string;
  location: EventLocation;
  startTime: string;
  endTime: string;
  recurrence: RecurrenceRule;
  coverImageUrl?: string;
  rsvpCounts: Record<RsvpStatus, number>;
  viewerRsvp?: RsvpStatus;
}
