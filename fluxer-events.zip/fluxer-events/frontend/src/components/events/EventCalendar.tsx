import { useMemo, useState } from "react";
import { useEvents } from "../../hooks/useEvents";
import { EventModal } from "./EventModal";
import type { CommunityEvent } from "./types";
import "./events.css";

interface EventCalendarProps {
  /** omit to show the viewer's personal calendar instead of a community's */
  communityId?: string;
  /** the signed-in user's id — plug in from wherever Fluxer's existing
   *  auth/session context lives (e.g. a `useCurrentUser()` hook) */
  viewerId: string;
  /** Fluxer's existing shared gateway socket client, if available —
   *  pass it through to get live updates; omit for fetch-on-mount only */
  gatewaySocket?: Parameters<typeof useEvents>[0]["gatewaySocket"];
}

const WEEKDAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function EventCalendar({
  communityId,
  viewerId,
  gatewaySocket,
}: EventCalendarProps) {
  const { events, isLoading, error, setRsvp } = useEvents({
    communityId,
    viewerId,
    gatewaySocket,
  });
  const [monthCursor, setMonthCursor] = useState(() => startOfMonth(new Date()));
  const [selectedEvent, setSelectedEvent] = useState<CommunityEvent | null>(
    null
  );

  const days = useMemo(() => buildMonthGrid(monthCursor), [monthCursor]);
  const eventsByDay = useMemo(() => groupEventsByDay(events), [events]);

  return (
    <div className="fx-events">
      <div className="fx-events-header">
        <h2>
          {monthCursor.toLocaleString(undefined, {
            month: "long",
            year: "numeric",
          })}
        </h2>
        <div className="fx-events-nav">
          <button
            onClick={() => setMonthCursor(addMonths(monthCursor, -1))}
            aria-label="Previous month"
          >
            ‹
          </button>
          <button
            onClick={() => setMonthCursor(startOfMonth(new Date()))}
          >
            Today
          </button>
          <button
            onClick={() => setMonthCursor(addMonths(monthCursor, 1))}
            aria-label="Next month"
          >
            ›
          </button>
        </div>
      </div>

      {error && (
        <p style={{ color: "#f23f42", padding: "0 16px", fontSize: 13 }}>
          {error}
        </p>
      )}

      <div className="fx-events-grid" role="grid" aria-label="Event calendar">
        {WEEKDAY_LABELS.map((label) => (
          <div key={label} className="fx-events-weekday">
            {label}
          </div>
        ))}

        {days.map(({ date, isCurrentMonth }) => {
          const key = dayKey(date);
          const dayEvents = eventsByDay.get(key) ?? [];
          const isToday = dayKey(new Date()) === key;

          return (
            <div
              key={key}
              className={[
                "fx-events-cell",
                !isCurrentMonth && "is-outside-month",
                isToday && "is-today",
              ]
                .filter(Boolean)
                .join(" ")}
              role="gridcell"
            >
              <span className="fx-events-date">{date.getDate()}</span>
              {dayEvents.slice(0, 3).map((event) => (
                <button
                  key={event.id}
                  className="fx-events-pill"
                  onClick={() => setSelectedEvent(event)}
                  title={event.title}
                >
                  {event.title}
                </button>
              ))}
              {dayEvents.length > 3 && (
                <span style={{ fontSize: 10, color: "var(--fx-text-muted)" }}>
                  +{dayEvents.length - 3} more
                </span>
              )}
            </div>
          );
        })}
      </div>

      {isLoading && (
        <p style={{ padding: 16, color: "var(--fx-text-muted)", fontSize: 13 }}>
          Loading events…
        </p>
      )}

      {!isLoading && events.length === 0 && !error && (
        <p style={{ padding: 16, color: "var(--fx-text-muted)", fontSize: 13 }}>
          No events yet. Create one to get this calendar going.
        </p>
      )}

      {selectedEvent && (
        <EventModal
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          onRsvp={(status) => {
            setRsvp(selectedEvent.id, status);
            setSelectedEvent({
              ...selectedEvent,
              viewerRsvp: status,
            });
          }}
        />
      )}
    </div>
  );
}

// ---- date helpers -----------------------------------------------------

function startOfMonth(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

function addMonths(date: Date, delta: number): Date {
  return new Date(date.getFullYear(), date.getMonth() + delta, 1);
}

function dayKey(date: Date): string {
  return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
}

/** Builds a 6-week grid (42 cells) covering the given month, including
 *  the leading/trailing days from adjacent months needed to fill weeks. */
function buildMonthGrid(monthStart: Date) {
  const firstWeekday = monthStart.getDay();
  const gridStart = new Date(monthStart);
  gridStart.setDate(gridStart.getDate() - firstWeekday);

  const days: { date: Date; isCurrentMonth: boolean }[] = [];
  for (let i = 0; i < 42; i++) {
    const date = new Date(gridStart);
    date.setDate(gridStart.getDate() + i);
    days.push({ date, isCurrentMonth: date.getMonth() === monthStart.getMonth() });
  }
  return days;
}

function groupEventsByDay(
  events: CommunityEvent[]
): Map<string, CommunityEvent[]> {
  const map = new Map<string, CommunityEvent[]>();
  for (const event of events) {
    const key = dayKey(new Date(event.startTime));
    const list = map.get(key) ?? [];
    list.push(event);
    map.set(key, list);
  }
  return map;
}
