import { useEffect, useRef } from "react";
import type { CommunityEvent, RsvpStatus } from "./types";

interface EventModalProps {
  event: CommunityEvent;
  onClose: () => void;
  onRsvp: (status: RsvpStatus) => void;
}

const RSVP_OPTIONS: { status: RsvpStatus; label: string }[] = [
  { status: "going", label: "Going" },
  { status: "interested", label: "Interested" },
  { status: "not_going", label: "Can't go" },
];

export function EventModal({ event, onClose, onRsvp }: EventModalProps) {
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    closeButtonRef.current?.focus();
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [onClose]);

  const start = new Date(event.startTime);
  const end = new Date(event.endTime);
  const timeRange = `${formatDateTime(start)} – ${formatTime(end)}`;

  return (
    <div
      className="fx-event-modal-backdrop"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="fx-event-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="fx-event-modal-title"
        style={{ position: "relative" }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          ref={closeButtonRef}
          className="fx-event-modal-close"
          onClick={onClose}
          aria-label="Close event details"
        >
          ✕
        </button>

        <h3 id="fx-event-modal-title">{event.title}</h3>
        <div className="fx-event-modal-time">{timeRange}</div>

        {event.description && (
          <p className="fx-event-modal-desc">{event.description}</p>
        )}

        {event.location.type === "voice_channel" && (
          <p className="fx-event-modal-desc">
            📍 Happening in a voice channel
          </p>
        )}
        {event.location.type === "external" && event.location.description && (
          <p className="fx-event-modal-desc">📍 {event.location.description}</p>
        )}

        <div className="fx-rsvp-counts">
          <span>{event.rsvpCounts.going} going</span>
          <span>{event.rsvpCounts.interested} interested</span>
        </div>

        <div className="fx-rsvp-row" role="group" aria-label="Your RSVP">
          {RSVP_OPTIONS.map(({ status, label }) => (
            <button
              key={status}
              className="fx-rsvp-button"
              data-status={status}
              data-active={event.viewerRsvp === status}
              aria-pressed={event.viewerRsvp === status}
              onClick={() => onRsvp(status)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function formatDateTime(date: Date): string {
  return date.toLocaleString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit",
  });
}
