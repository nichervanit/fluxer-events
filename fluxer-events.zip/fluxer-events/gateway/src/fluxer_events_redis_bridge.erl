%%%-------------------------------------------------------------------
%%% fluxer_events_redis_bridge
%%%
%%% CAVEAT (same as fluxer_events_pubsub.erl): I don't know if Fluxer's
%%% Erlang gateway already has a Redis client dependency for other
%%% real-time features. This assumes `eredis` (the most common Erlang
%%% Redis client) is available. If the gateway already uses a
%%% different client (e.g. `redix` is Elixir-only, wouldn't apply here;
%%% but check for a existing redis app in the release config), adapt
%%% the subscribe/message-receive calls to that client's API instead
%%% of adding a second Redis dependency.
%%%
%%% Responsibility: subscribe to the pattern `events:*` on Redis (using
%%% PSUBSCRIBE, since we don't know channel names upfront — one exists
%%% per community/user), and forward each message to
%%% fluxer_events_pubsub:broadcast/2 using the channel name as the pg
%%% topic. This is the ONLY thing this module does — it deliberately
%%% contains no business logic, so a bad message here can't corrupt
%%% event state (Node/the DB remains the source of truth).
%%%-------------------------------------------------------------------
-module(fluxer_events_redis_bridge).
-behaviour(gen_server).

-export([start_link/1]).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
         terminate/2, code_change/3]).

-record(state, {redis_conn :: pid()}).

%% ------------------------------------------------------------------
%% Public API
%% ------------------------------------------------------------------

%% RedisOpts, e.g. #{host => "localhost", port => 6379} — reuse
%% whatever config Fluxer's other Redis-backed features already read
%% from, rather than introducing a second config path.
-spec start_link(RedisOpts :: map()) -> {ok, pid()} | {error, term()}.
start_link(RedisOpts) ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, RedisOpts, []).

%% ------------------------------------------------------------------
%% gen_server callbacks
%% ------------------------------------------------------------------

init(RedisOpts) ->
    Host = maps:get(host, RedisOpts, "localhost"),
    Port = maps:get(port, RedisOpts, 6379),
    %% eredis_sub is the pub/sub-specific client in the eredis package;
    %% plain eredis:start_link/2 does not support subscriptions.
    case eredis_sub:start_link(Host, Port) of
        {ok, Conn} ->
            eredis_sub:controlling_process(Conn),
            eredis_sub:psubscribe(Conn, [<<"events:*">>]),
            {ok, #state{redis_conn = Conn}};
        {error, Reason} ->
            {stop, Reason}
    end.

%% eredis_sub delivers pattern-subscribed messages as this tuple shape.
handle_info(
    {message, Channel, Payload, _Pid},
    State
) ->
    safe_broadcast(Channel, Payload),
    {noreply, State};
handle_info({pmessage, _Pattern, Channel, Payload, _Pid}, State) ->
    safe_broadcast(Channel, Payload),
    {noreply, State};
handle_info({eredis_disconnected, _Pid}, State) ->
    %% Log-and-continue: eredis_sub reconnects automatically. A gap in
    %% real-time delivery during a reconnect is acceptable — clients
    %% still see correct state on their next poll/reconnect, since
    %% Postgres/SQLite remains the source of truth. This bridge is
    %% strictly best-effort.
    error_logger:warning_msg(
        "fluxer_events_redis_bridge: redis disconnected, awaiting reconnect~n"
    ),
    {noreply, State};
handle_info(_Info, State) ->
    {noreply, State}.

handle_call(_Request, _From, State) ->
    {reply, {error, unimplemented}, State}.

handle_cast(_Msg, State) ->
    {noreply, State}.

terminate(_Reason, _State) ->
    ok.

code_change(_OldVsn, State, _Extra) ->
    {ok, State}.

%% ------------------------------------------------------------------
%% Internal
%% ------------------------------------------------------------------

%% Never let a malformed message from Redis crash this process — if
%% fluxer_events_pubsub isn't running yet, or the payload is garbage,
%% log and move on rather than taking down the connection.
safe_broadcast(Channel, Payload) ->
    try
        fluxer_events_pubsub:broadcast(Channel, Payload)
    catch
        Class:Reason ->
            error_logger:error_msg(
                "fluxer_events_redis_bridge: broadcast failed for ~p: ~p:~p~n",
                [Channel, Class, Reason]
            )
    end.
