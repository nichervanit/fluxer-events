%%%-------------------------------------------------------------------
%%% fluxer_events_pubsub
%%%
%%% CAVEAT: I don't have access to Fluxer's actual gateway codebase, so
%%% this is a plausible OTP pattern for topic-based broadcast (using
%%% `pg`, Erlang/OTP's built-in process-group module), NOT verified
%%% against their real supervision tree, session/connection registry,
%%% or wire protocol. Someone who knows the actual gateway needs to:
%%%   1. Wire this into the existing supervisor (add as a child spec)
%%%   2. Replace the placeholder `send_to_socket/2` with however the
%%%      gateway actually pushes frames to a client connection process
%%%   3. Confirm the topic-naming convention doesn't collide with
%%%      existing pg groups (channels, presence, etc.)
%%%
%%% Intent: one `pg` group per community ("events:community:<id>") and
%%% one per user ("events:user:<id>") for personal-calendar updates.
%%% Gateway connection processes join the relevant group(s) on
%%% connect/auth; this module publishes to those groups on mutation.
%%%-------------------------------------------------------------------
-module(fluxer_events_pubsub).
-behaviour(gen_server).

-export([start_link/0]).
-export([subscribe/2, unsubscribe/2, broadcast/2]).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
         terminate/2, code_change/3]).

-define(SCOPE, fluxer_events_scope).

%% ------------------------------------------------------------------
%% Public API
%% ------------------------------------------------------------------

start_link() ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, [], []).

%% ConnectionPid is whatever process owns the client's socket/websocket
%% in the real gateway — adapt this to the actual connection handler type.
-spec subscribe(Topic :: binary(), ConnectionPid :: pid()) -> ok.
subscribe(Topic, ConnectionPid) ->
    ok = pg:join(?SCOPE, Topic, ConnectionPid).

-spec unsubscribe(Topic :: binary(), ConnectionPid :: pid()) -> ok.
unsubscribe(Topic, ConnectionPid) ->
    ok = pg:leave(?SCOPE, Topic, ConnectionPid).

%% Payload should already be encoded (e.g. JSON binary) by the caller,
%% matching whatever frame format the gateway's other events use.
-spec broadcast(Topic :: binary(), Payload :: binary()) -> ok.
broadcast(Topic, Payload) ->
    Members = pg:get_members(?SCOPE, Topic),
    lists:foreach(
        fun(ConnectionPid) -> send_to_socket(ConnectionPid, Payload) end,
        Members
    ),
    ok.

%% ------------------------------------------------------------------
%% gen_server callbacks
%% ------------------------------------------------------------------

init([]) ->
    %% `pg` scopes must be started once per node, typically from the
    %% top-level application supervisor — move this if one is already
    %% started elsewhere for other features.
    case pg:start_link(?SCOPE) of
        {ok, _Pid} -> ok;
        {error, {already_started, _Pid}} -> ok
    end,
    {ok, #{}}.

handle_call(_Request, _From, State) ->
    {reply, {error, unimplemented}, State}.

handle_cast(_Msg, State) ->
    {noreply, State}.

handle_info(_Info, State) ->
    {noreply, State}.

terminate(_Reason, _State) ->
    ok.

code_change(_OldVsn, State, _Extra) ->
    {ok, State}.

%% ------------------------------------------------------------------
%% Internal
%% ------------------------------------------------------------------

%% PLACEHOLDER: replace with the real send mechanism, e.g.
%%   ConnectionPid ! {push_frame, Payload}
%% or a call into whatever cowboy_websocket handler module already
%% exists for other real-time features (presence, typing indicators).
send_to_socket(ConnectionPid, Payload) ->
    ConnectionPid ! {events_update, Payload}.
